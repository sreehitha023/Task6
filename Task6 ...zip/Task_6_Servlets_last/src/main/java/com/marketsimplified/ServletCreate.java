package com.marketsimplified;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;


@WebServlet("/ServletCreate")

public class ServletCreate extends HttpServlet

{
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {

		try {

			response.setContentType("application/json");
			StringBuffer jb = new StringBuffer();
			String line = null;
			BufferedReader reader = request.getReader();
			while ((line = reader.readLine()) != null) 
			{
				jb.append(line);
			}
			JSONObject jsobj = new JSONObject(jb.toString());
			String name = jsobj.getString("name");
			int age = jsobj.getInt("age");
			int salary = jsobj.getInt("salary");
			int fourthValue = jsobj.getInt("fourthValue");
			int emptype = jsobj.getInt("emptype");
			EmployeeDatabase emp = new EmployeeDatabase();
			String jsonData = emp.addEmployee(name, age, salary, fourthValue, emptype);
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			PrintWriter out = response.getWriter();
			out.write(jsonData);
		} catch (Exception e1) {
			System.out.println(e1);
		} 

	}

}
