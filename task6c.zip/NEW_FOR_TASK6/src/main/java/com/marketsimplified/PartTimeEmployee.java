package com.marketsimplified;

public class PartTimeEmployee extends Employee
{
    final private int hoursWorked;
    public PartTimeEmployee(String name, int age, int salary, int hoursWorked)
    {
        super(name, age, salary);
        this.hoursWorked = hoursWorked;
    }
    public int getHoursWorked()
    {
        return hoursWorked;
    }
}